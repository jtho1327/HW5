#pragma once
#include "SignalBlock.h"
namespace justin
{
    class ddt : public ELCT350::SignalBlock
    {
    public:
       
        enum Ports : size_t
        {
           Output,
           Input
        };

        ddt();
        virtual void step(double time, double timeStep) override;
    private:
        double prevInput;

    };
}