#pragma once
#include "SignalBlock.h"

namespace justin
{
	class Sum : public ELCT350::SignalBlock
	{
	public:
		enum Parameters : size_t
		{
			sumValue1,
			sumValue2
		};
		enum Ports : size_t
		{
			Output,
			Input1,
			Input2
		};
		Sum(double val1, double val2);
		virtual void step(double time, double timeStep) override;
	};
}