#pragma once
#include "SignalBlock.h"

namespace justin
{
	class Gain : public ELCT350::SignalBlock
	{
	public:
		enum Parameters : size_t
		{
			gainValue
		};
		enum Ports : size_t
		{
			Output,
			Input
		};
		Gain(double gain);
		virtual void step(double time, double timeStep) override;
	};
}