#pragma once
#include "SignalBlock.h"

namespace justin

{
    class Constant : public ELCT350::SignalBlock
    {
    public:
        enum Parameters : size_t
        {
            Con
        };
        enum Ports : size_t
        {
            Output
        };
        Constant(double con);
        virtual void step(double time, double timeStep) override;
    };
}