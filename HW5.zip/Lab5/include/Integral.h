#pragma once
#include "SignalBlock.h"

namespace justin

{
	class Integral : public ELCT350::SignalBlock
	{
	public:
		enum Parameters : size_t
		{
			iVal
		};
		enum Ports : size_t
		{
			Output,
			Input
		};

		Intergral(double in);
		virtual void step(double time, double timeStep) override;
	};
}