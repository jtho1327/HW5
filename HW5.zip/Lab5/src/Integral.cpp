#include <cmath>
#include "Integral.h"
#include "SignalBlock.h"

using namespace justin;
Integral::Integral()
	:SignalBlock(1, 2), prevI(0.0)
{
}
void Integral::step(double time, double timeStep)
{
	setPortValue(Output, (getPortValue(Input)))
}