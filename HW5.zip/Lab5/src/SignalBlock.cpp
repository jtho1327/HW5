#include "SignalBlock.h"

using namespace ELCT350;

SignalBlock::SignalBlock(size_t numParameters, size_t numPorts)
{
  for (size_t parameterIndex = 0; parameterIndex < numParameters; ++parameterIndex)
  {
    _parameters.push_back(0.0);
  }
  for (size_t portIndex = 0; portIndex < numPorts; ++portIndex)
  {
      _ports.push_back(0.0);
  }
}

void SignalBlock::setParameter(size_t parameterIndex, double parameter)
{
  _parameters[parameterIndex] = parameter;
}

double SignalBlock::getParameter(size_t parameterIndex) const
{
  return _parameters.at(parameterIndex);
}

void SignalBlock::setPortValue(size_t portIndex, double portValue)
{
    _ports[portIndex] = portValue;
}

double SignalBlock::getPortValue(size_t portIndex) const
{
    return _ports.at(portIndex);
}