#include <cmath>
#include "Sum.h"
#include "SignalBlock.h"

using namespace justin;

double Sum(double val1, double val2)
{
	return val1 + val2;
}
Sum::Sum(double val1, double val2)
	:SignalBlock(2, 3)
{
	setParameter(sumValue1, val1);
	setParameter(sumValue2, val2);
}
void Sum::step(double time, double timeStep)
{
	setPortValue(Output, getParameter(sumValue1) + getParameter(sumValue2));
}