#include <cmath>
#include "ddt.h"
#include "SignalBlock.h"

using namespace justin;

ddt::ddt()
    :SignalBlock(0, 2), prevInput(0.0)
{
}
void ddt::step(double time, double timeStep)
{
    setPortValue(Output, (getPortValue(Input) - prevInput) / timeStep);
    prevInput = getPortValue(Input);
}