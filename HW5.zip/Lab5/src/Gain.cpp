#include <cmath>
#include "Gain.h"
#include "SignalBlock.h"

using namespace justin;

Gain::Gain(double gain)
	: SignalBlock(1, 2)
{
	setParameter(gainValue, gain);
}

void Gain::step(double time, double timeStep)
{
	setPortValue(gainValue, getParameter(gainValue));
}