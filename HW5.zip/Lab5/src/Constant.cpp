#include <cmath>
#include "Constant.h"
#include "SignalBlock.h"

using namespace justin;

Constant::Constant(double con)
	: SignalBlock(1, 1)
{
	setParameter(Con, con);
}

void Constant::step(double time, double timeStep)
{
	setPortValue(Con, getParameter(Con));
}